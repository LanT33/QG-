#include "LQueue.h"

int main()
{
	int flag = 0;
	LQueue *head = (LQueue*)malloc(sizeof(LQueue));
	head->front = head->rear = NULL;
	head->length = 0;
	while(TRUE)
	{

    	system("cls");
    	printf(" ���й���\n--------------------------\n");
        printf(" 1.����˳��ջ               \n");
        printf(" 2.�������                 \n");
        printf(" 3.���ݳ���                 \n");//
        printf(" 4.�ж϶����Ƿ�Ϊ��         \n");
       // printf(" 5.�ж϶����Ƿ�����         \n");////
        printf(" 5.��ȡ������λ����         \n");
        printf(" 6.��ն���                 \n");
        printf(" 7.���ٶ���                 \n");
        printf(" 8.�����г���             \n");
        printf(" 9.��ӡ����                \n");
        printf(" 10.�˳�                    \n");
        printf("--------------------------  \n");
        printf("--------------------------  \n");
        printf("��ǰ����״̬:\n");
        if(flag)
        {

              TraverseLQueue(head,&LPrint);
              printf("\n");
            printf("front:%d",*(int*)(head->front->data));//,*(int*)(head->rear->data),head->length    ,rear:%f\n,length:%d
        }
        else
        {
                printf("û�ж���\n");
        }
	printf("--------------------------\n");
        printf("������ſ����ж�Ӧ����:");
	 switch(Input())
        {
                case 1:
			if(!flag)
			{
                                LOOG:
				InitLQueue(head);
				flag = 1;
				break;
			}
			else
			{
			        DestoryLQueue(head);
			        goto LOOG;
				//printf("���ж���\n");
				break;
			}
               case 2:
                        if(flag)
                        {
                                double i[2]={0};
                                printf("������Ҫ��ӵ�����:");
                                //if(type == 'i'||type == 'l'||type == 'f')
                                        //i[0]=Input();
                                InputData(&i);
                                EnLQueue(head,&i);
                        }
                        else
                        {
                               printf("û�ж���\n");
                        }
                        break;
                case 3:
                        if(flag)
                        {
                                int j = DeLQueue(head);
                                if(j == FALSE)
                                {
                                       printf("�����ѿ�");
                                }

                        }
                        else
                        {
                                printf("û�ж���\n");
                        }
                        break;
                case 4:
                        if(flag)
                        {
                                int y = IsEmptyLQueue(head);
                                if(y == FALSE)
                                        printf("����δ��");
                                else
                                        printf("�����ѿ�");
                                break;
                        }
                        else
                        {
                                printf("û�ж���\n");
                                break;
                        }

               /* case 5:
                        if(flag)
                        {
                                IsFullLQueue(head);
                        }
                        else
                        {
                                printf("û�ж���\n");
                        }
                        break;*/
                case 5:
			if(flag)
                        {
                                int t;
				double j;
				t = GetHeadLQueue(head,&j);
				//printf("t:%d\n",t);
                                if(t == TRUE)
                                {
                                        if(type == 'i')
                                        printf("λ�ڶ�����λ�������ǣ�%d",j);
                                        else if(type == 'l')
                                                printf("λ�ڶ�����λ�������ǣ�%ld",j);
                                        else if(type == 'f')
                                                printf("λ�ڶ�����λ�������ǣ�%f",j);
                                        else if(type == 'd')
                                                printf("λ�ڶ�����λ�������ǣ�%lf",j);
                                        else if(type == 'c')
                                                printf("λ�ڶ�����λ�������ǣ�%c",j);
                                }
                        }
                        else
                        {
                                printf("û�ж���\n");
                        }
                        break;
                case 6:
                        if(flag)
                        {
				ClearLQueue(head);
                        }
                        else
                        {
                               printf("û�ж���\n");
                        }
                        break;
                case 7:
                        if(flag)
                        {
                                DestoryLQueue(head);
                                flag = 0;
                        }
                        else
                        {
                              printf("û�ж���\n");
                        }
                        break;
                case 8:
                        if(flag)
                        {
                                printf("����Ϊ��%d\n",LengthLQueue(head));
                        }
                        else
                        {
                               printf("û�ж���\n");
                        }
                        break;
                case 9:
                        TraverseLQueue(head,&LPrint);
                        printf("\n");
                        break;
                case 10:
                        exit(0);
                default:
                        printf("�޸����\n");
                        break;
        }
        system("pause");
    }
    return 0;
}
