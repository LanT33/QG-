#include "LQueue.h"

char type;
int data_size = 0;

/**
 *  @name        : void InitLQueue(LQueue *Q)
 *  @description : initialize LQueue
 *  @param       : Q (pointer of AQueue)
 *  @notice      : None
 */
void InitLQueue(LQueue *Q)
{
	Q->front = Q->rear = (Node *) malloc(sizeof(Node));
	data_size = InputType();
	Q->front->data = (void *) malloc(data_size);//NULL;
	Q->length = 0;
	Q->front->next = NULL;
	printf("��ʼ���ɹ���\n");
}

/**
 *  @name        : void DestroyLQueue(LQueue *Q)
 *  @description : Destroy  LQueue
 *  @param       : Q (pointer of LQueue)
 *  @notice      : None
 */
void DestoryLQueue(LQueue *Q)
{
	if (Q->length == 0)
		return;
	Node *p = Q->front;
	Node *q = p;
	Q->front = Q->rear = (Node *) malloc(sizeof(Node));////
	Q->length = 0;

	while (p != NULL)
	{

		q = p;
		p = p->next;//p = q->next;
		free(q->data);//free(p->data);
		free(q);//free(p);
			//	q = p;

	}
	free(Q->front);
	Q->front = Q->rear = NULL;
	Q = NULL;
}

/**
 *  @name        : Status IsEmptyLQueue(const LQueue *Q)
 *  @description : check if the LQueue is empty.
 *  @param       : Q (pointer of LQueue)
 *  @return      : full-TRUE; not full-FALSE
 *  @notice      : None
 */
Status IsEmptyLQueue(const LQueue *Q)
{
	if (Q->length == 0)
		return TRUE;
	else
		return FALSE;
}

/**
 *  @name        : Status GetHeadLQueue(LQueue *Q, void *e)
 *  @description : check head's data of the LQueue
 *  @param       : Q (pointer of LQueue);e save the Head's data
 *  @return      : success-TRUE; error-FALSE
 *  @notice      : LQueue is empty or not.
 */
Status GetHeadLQueue(LQueue *Q, void *e)
{
	if (Q->front == NULL)
	{
		printf("����Ϊ��");
		return FALSE;
	}
	memcpy(e,Q->front->data,data_size);//->data
	if (e == NULL)
	{
		return FALSE;
	}
	else
		return TRUE;
}

/**
 *  @name        : int LengthLQueue(LQueue *Q)
 *  @description : ensure teh length of LQueue.
 *  @param       : Q (pointer of LQueue)
 *  @return      : count(the length of LQueue).
 *  @notice      : None
 */
int LengthLQueue(LQueue *Q)
{
    return Q->length;
}

/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *  @description : date enter LQueue.
 *  @param       : Q (pointer of LQueue);data(the pointer of date added LQueue.)
 *  @return      : success-TRUE; error-FALSE
 *  @notice      : LQueue is empty or not.
 */
Status EnLQueue(LQueue *Q, void *data)
{
    Node *p = (Node *) malloc(sizeof(Node));
    p->data = (void *) malloc(data_size);////����ʵ�ָ���㲻ͬ��������
    memcpy(p->data, data, data_size);
    p->next = NULL;

    if (Q->front == NULL)
	Q->front = p;
  //  if (Q->rear == NULL)
//	Q->rear = p;
    if (Q->length == 0)
	Q->front = Q->rear = p;
    else
    {
        Q->rear->next = p;
        Q->rear = p;
   }
    Q->length++;
    printf("�ɹ����\n");
}

/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *  @description : data out of LQueue
 *  @param       : Q (pointer of LQueue)
 *  @return      : success-TRUE; error-FALSE
 *  @notice      : None
 */
Status DeLQueue(LQueue *Q)
{
    if (Q->front == NULL)
    {
    	printf("dddd");
	return FALSE;
    }
   // if(Q->)
    Node *p = Q->front;
    Q->front = p->next;
   // if(Q->front == Q->rear)
//	Q->front = Q->rear = NULL;////
    if(Q->length !=0)////
    Q->length--;
    free(p);
    p = NULL;
    printf("�ɹ�����\n");

    return TRUE;
}

/**
 *  @name        : void ClearLQueue(AQueue *Q)
 *  @description : clear the LQueue
 *  @param       : Q (pointer of LQueue)
 *  @notice      : None
 */
void ClearLQueue(LQueue *Q)
{
    Node *p = Q->front;
    Node *q = p;
    Q->front = Q->rear = (Node *) malloc(sizeof(Node));
    Q->length = 0;
    while (p != NULL) {
        q = p;
        p = p->next;
        free(q->data);
        free(q);
    }
}

/**
 *  @name        : Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q))
 *  @description : traverse LQueue
 *  @param       : Q (pointer of LQueue);foo(the funtion uesed to print right data)
 *  @return      : None
 *  @notice      : None
 */
Status TraverseLQueue(const LQueue *Q, void(*foo)(void *q)) {
	if (IsEmptyLQueue(Q))
	{
		printf("����Ϊ��");
		return FALSE;
	}
	Node *p = Q->front;

	while (p)
	{
		foo(p->data);
		if (p->next == NULL)//||p == NULL
			return TRUE;
		printf("<-- ");
		p = p->next;
	}
}

/**
 *  @name        : void LPrint(void *q)
 *  @description : the funtion uesed to print right data
 *  @param       : q(pointer)
 *  @notice      : None
 */
void LPrint(void *q)
{
	if (type == 'i')
	{
		int *e = (int *) q;
		printf("%d", *e);
	}
	else if (type == 'l')
	{
		long *e = (long *) q;
		printf("%ld", *e);
	}
	else if (type == 'f')
	{
		float *e = (float *) q;
		printf("%f", *e);
	}
	else if (type == 'd')
	{
		double *e = (double *) q;
		printf("%lf", *e);
	}
	else if (type == 'c')
	{
		char *e = (char *) q;
		printf("%c", *e);
	}
}

/**
 *  @name        : int Input()
 *	@description : anti-input-error
 *	@param		 : none
 *	@return		 : int
*/
int Input()
{
	int num = 0;
	int status = 0;
	char str[100];
	do
	{
		scanf("%s", str);
		status = TRUE;
		int i;
		for (i=0;str[i]!='\0';i++)
		{

			if (i == 0)
			{
				if (str[i]=='-'||str[i]=='+'/*||str[i] == '.'*/)
					continue;
			}
			else
			{
				if (str[i] < '0' || str[i] > '9')
				{
					status = FALSE;
				}
			}
		}
		if (status == FALSE)
		{
			printf("����������������:");
		}
		else
		{
			 i = 0;
			for (i = 0, num = 0; str[i] != '\0'; i++)
			{
				if (i == 0)
				{
					if (str[i] == '-' || str[i] == '+')
					{
						continue;
					}
					else
					{
						num *= 10;
						num += (str[i] - 48);
					}
				}
				else
				{
					num *= 10;
					num += (str[i] - 48);
				}
			}
			if (str[0] == '-')
			{

				num = -num;
			}
			// Check if the number entered is out of bounds.
			if (i>=10)
			{
				printf("������Χ������������:");
				status = FALSE;
			}
		}
	} while (status == FALSE);
	return num;
}

/**
 *  @name        : InputType
 *	@description : Get the data type
 *	@param		 : None
 *	@return		 : int
 *  @notice      : None
 */
 int InputType()
 {
 	int ret = 0;
 	int t = 0;
 	int a = 0;
 	do
	{
		ret = -1;
		t +=1;
		a +=1;
		if(t > 1)
		{
			printf("\n����س�\n");
			getchar();
		}
		//if(t)type == '\n'||
		if(t > 1)
		{
			printf("\ni->int///l->long///f->float///d->double///c->char\n");

			printf("ѡ��Ҫ��������ݵ���������:\n");
			printf("�������ѡ��");
			type = getchar();
			ret = -1;
			//t++;
			//continue;
		}

		if(t==2)
		{
			t = 0;
			if(type == 'i')
				return 4;
			else if(type == 'l')
				return 8;
			else if(type == 'f')
				return 4;
			else if(type == 'd')
				return 8;
			else if(type == 'c')
				return 1;
			t = 3;
		}
		if(t > 2)
		{
			ret = -1;
			t = 0;
			printf("\n�������ɵ���������,����������:");
		}
 	}while(ret == -1);
 	t = 0;
 	return 0;
 }

/**
 *  @name        : InputData
 *	@description : Get the data
 *	@param		 : None
 *	@return		 : None
 *  @notice      : None
 */

void InputData(void *data)
{
	int ret = 0;
	do
	{
		ret = 0;
		//if (getchar() == '\n')
		//{
		if (type == 'i')
			scanf("%d", data, data_size);
		else if (type == 'l')
			scanf("%ld", data, data_size);
		else if (type == 'f')
			scanf("%f", data, data_size);
		else if (type == 'd')
			scanf("%lf", data, data_size);
		else if (type == 'c')
			scanf("%c", data, data_size);

		//	return ;
		//}
		if(getchar() != '\n')
		{
			ret = -1;
			for (; getchar() != '\n';);
			printf("�������������룬����������:", ret);
		}
		else
			return;
	} while (ret == -1);
}
