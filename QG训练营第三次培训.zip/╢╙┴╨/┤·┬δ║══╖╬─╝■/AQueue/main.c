#include "AQueue.h"

int main()
{
	int flag = 0;
	AQueue *head = (AQueue*)malloc(sizeof(AQueue));
	head->front = head->rear = head->length = 0;
	while(TRUE)
	{

    	system("cls");
    	printf(" ˳����й���\n--------------------------\n");
        printf(" 1.����˳��ջ               \n");
        printf(" 2.�������                 \n");
        printf(" 3.���ݳ���                 \n");//
        printf(" 4.�ж϶����Ƿ�Ϊ��         \n");
        printf(" 5.�ж϶����Ƿ�����         \n");////
        printf(" 6.��ȡ������λ����         \n");
        printf(" 7.��ն���                 \n");
        printf(" 8.���ٶ���                 \n");
        printf(" 9.�����г���             \n");
        printf(" 10.��ӡ����                \n");
        printf(" 11.�˳�                    \n");
        printf("--------------------------  \n");
        printf("--------------------------  \n");
        printf("��ǰ����״̬:\n");
        if(flag)
        {

              TraverseAQueue(head,&APrint);
              printf("\n");
             // printf("front:%d,rear:%d\n",head->front,head->rear);
        }
        else
        {
                printf("û�ж���\n");
        }
	printf("--------------------------\n");
        printf("������ſ����ж�Ӧ����:");
	 switch(Input())
        {
                case 1:
			if(!flag)
			{
                                LOOG:
                                printf("\ni->int///l->long///f->float///d->double///c->char\n");
                                printf("ѡ��Ҫ��������ݵ���������:\n");
                                printf("�������ѡ��");
				InitAQueue(head);
				flag = 1;
				break;
			}
			else
			{
			        DestoryAQueue(head);
			        goto LOOG;
				//printf("���ж���\n");
				break;
			}
               case 2:
                        if(flag)
                        {
                                double i[10]={0};
                                printf("������Ҫ��ӵ�����:");
                                //if(type == 'i'||type == 'l'||type == 'f')
                                        //i[0]=Input();
                                        InputData(&i);
                                EnAQueue(head,&i);
                        }
                        else
                        {
                               printf("û�ж���\n");
                        }
                        break;
                case 3:
                        if(flag)
                        {
                                int j = DeAQueue(head);
                                if(j == FALSE)
                                {
                                       printf("�����ѿ�");
                                }

                        }
                        else
                        {
                                printf("û�ж���\n");
                        }
                        break;
                case 4:
                        if(flag)
                        {
                                int y = IsEmptyAQueue(head);
                                if(y == FALSE)
                                        printf("����δ��");
                                else
                                        printf("�����ѿ�");
                                break;
                        }
                        else
                        {
                                printf("û�ж���\n");
                                break;
                        }

                case 5:
                        if(flag)
                        {
                                IsFullAQueue(head);
                        }
                        else
                        {
                                printf("û�ж���\n");
                        }
                        break;
                case 6:
			if(flag)
                        {
                                int t;
				long long j;
				t = GetHeadAQueue(head,&j);
                                if(t == TRUE)
                                {
                                        if(type == 'i')
                                        printf("λ�ڶ�����λ�������ǣ�%d",j);
                                        else if(type == 'l')
                                                printf("λ�ڶ�����λ�������ǣ�%ld",j);
                                        else if(type == 'f')
                                                printf("λ�ڶ�����λ�������ǣ�%f",j);
                                        else if(type == 'd')
                                                printf("λ�ڶ�����λ�������ǣ�%lf",j);
                                        else if(type == 'c')
                                                printf("λ�ڶ�����λ�������ǣ�%c",j);
                                }
                        }
                        else
                        {
                                printf("û�ж���\n");
                        }
                        break;
                case 7:
                        if(flag)
                        {
				ClearAQueue(head);
                        }
                        else
                        {
                               printf("û�ж���\n");
                        }
                        break;
                case 8:
                        if(flag)
                        {
                                DestoryAQueue(head);
                                flag = 0;
                        }
                        else
                        {
                              printf("û�ж���\n");
                        }
                        break;
                case 9:
                        if(flag)
                        {
                                printf("����Ϊ��%d\n",LengthAQueue(head));
                        }
                        else
                        {
                               printf("û�ж���\n");
                        }
                        break;
                case 10:
                        TraverseAQueue(head,&APrint);
                        printf("\n");
                        break;
                case 11:
                        exit(0);
                default:
                        printf("�޸����\n");
                        break;
        }
        system("pause");
    }
    return 0;
}
