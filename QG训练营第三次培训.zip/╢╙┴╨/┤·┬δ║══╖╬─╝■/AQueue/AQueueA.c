#include "AQueue.h"
//#define MAXQUEUE 10
char type;
int data_size = 0;


/**
 *  @name        : void InitAQueue(AQueue *Q)
 *  @description : initialize AQueue
 *  @param       : Q (pointer of AQueue)
 *  @notice      : None
 */
void InitAQueue(AQueue *Q)
{
	data_size = InputType();
	for (int i = 0;i <=MAXQUEUE;i++)////
		Q->data[i] = (void *)malloc (sizeof(data_size));
	Q->front = Q->rear = 0;
	Q->length = 0;
	printf("�ɹ���ʼ�����С�\n");
}

/**
 *  @name        : void DestroyAQueue(AQueue *Q)
 *  @description : Destroy  AQueue
 *  @param       : Q (pointer of AQueue)
 *  @notice      : None
 */
 void DestoryAQueue(AQueue *Q)
 {
 	for(int i = 0;i < MAXQUEUE;i++)
	{
		free(Q->data[i]);
		Q->data[0] = NULL;
	}
	Q->front = Q ->rear = 0;
	Q->length = 0;
 }


 /**
 *  @name        : Status IsFullAQueue(const AQueue *Q)
 *  @description : check if the AQueue is full.
 *  @param       : Q (pointer of AQueue)
 *  @return      : full-TRUE; not full-FALSE
 *  @notice      : None
 */

 Status IsFullAQueue(const AQueue *Q)
 {
 	if((Q->rear + 1) % MAXQUEUE+1 == Q->front) //rear + 1  = MAXQUEUE,ѭ������
	{
		printf("��������\n");
		return TRUE;
	}
	else
	{
		printf("����δ��\n");
		return FALSE;
	}
 }


/**
 *  @name        : Status IsEmptyAQueue(const AQueue *Q)
 *  @description : check if the AQueue is empty.
 *  @param       : Q (pointer of AQueue)
 *  @return      : full-TRUE; not full-FALSE
 *  @notice      : None
 */

 Status IsEmptyAQueue(const AQueue *Q)
 {
	if(Q->data[0] == NULL)
	{
		printf("����Ŀǰδ��ʼ�������ȳ�ʼ�����У�\n");
		return FALSE;
	}
	if(Q->length == 0)////
	{
		return TRUE;
	}
	else
	{

		return FALSE;
	}
 }

/**
 *  @name        : Status GetHeadAQueue(AQueue *Q, void *e)
 *  @description : check head's data of the AQueue
 *  @param       : Q (pointer of AQueue);e save the Head's data
 *  @return      : success-TRUE; error-FALSE
 *  @notice      : AQueue is empty or not.
 */

 Status GetHeadAQueue(AQueue *Q,void *e)
 {
 	if(IsEmptyAQueue(Q))
	{
		return FALSE;
	}
	memcpy(e,Q->data[Q->front],data_size);////
	return TRUE;
 }

 /**
 *  @name        : int LengthAQueue(AQueue *Q)
 *  @description : ensure teh length of AQueue.
 *  @param       : Q (pointer of AQueue)
 *  @return      : count(the length of AQueue).
 *  @notice      : None
 */

int LengthAQueue(AQueue *Q)
{
	return Q->length;//(Q->rear-Q->front+Q->length)%Q->length;
}

/**
 *  @name        : Status EnAQueue(AQueue *Q, void *data)
 *  @description : date enter AQueue.
 *  @param       : Q (pointer of AQueue);data(the pointer of date added AQueue.)
 *  @return      : success-TRUE; error-FALSE
 *  @notice      : AQueue is empty or not.
 */
Status EnAQueue(AQueue *Q,void *data)
{
	if (Q->length == MAXQUEUE)
	{
		printf("����������\n");
		return FALSE;
	}
	if(Q->rear == MAXQUEUE)
		memcpy(Q ->data[Q->rear = 0],data,data_size);
	if(Q->front == MAXQUEUE)
		Q->front = 0;
	else
	{
		if(Q->length == 0)
			memcpy(Q->data[Q->rear],data,data_size);
		else
		{
			memcpy(Q->data[Q->rear + 1],data,data_size);
			Q->rear++;
		}
	}
	Q->length++;
	return TRUE;
}

/**
 *  @name        : Status DeAQueue(AQueue *Q)
 *  @description : data out of AQueue
 *  @param       : Q (pointer of AQueue)
 *  @return      : success-TRUE; error-FALSE
 *  @notice      : None
 */

 Status DeAQueue(AQueue *Q)
 {
	if(Q->rear == MAXQUEUE&&Q->front == Q->rear)
		return FALSE;
 	if(Q->front == Q->rear+1)//+1
	{
		Q->rear+=1;
		return FALSE;
	}
	if(Q->front == MAXQUEUE)//-1
		Q->front = 0;
	else
		Q->front++;
	Q->length--;
	printf("�����ѳ���");
 }

 /**
 *  @name        : void ClearAQueue(Queue *Q)
 *  @description : clear the AQueue
 *  @param       : Q (pointer of AQueue)
 *  @notice      : None
 */

 void ClearAQueue(AQueue *Q)
 {
 	Q->front = Q->rear = 0;
 	Q->length = 0;
 }

 /**
 *  @name        : Status TraverseAQueue(const AQueue *Q, void (*foo)(void *q))
 *  @description : traverse AQueue
 *  @param       : Q (pointer of AQueue);foo(the funtion uesed to print right data)
 *  @return      : None
 *  @notice      : None
 */

 Status TraverseAQueue(const AQueue *Q,void(*foo)(void*q))
 {
 	if(IsEmptyAQueue(Q))
	{
		//printf("����Ϊ�ա�\n");
		return FALSE;
	}
	int count = 0;
	/*int i = 0;
	while (i < (MAXQUEUE - Q->front + Q->rear) % MAXQUEUE) {
    		foo(Q->data[Q->front+i]);
    		i = (i + 1) % MAXQUEUE;
    		printf("<--");
    	}
    	return TRUE;*/
	for(int i =Q->front;;i++)//Q->front != '\0'
	{
		if(i == MAXQUEUE)////
			i = 0;
		foo(Q->data[i]);
		count++;
		if(count == Q->length)
			return TRUE;
		printf("<--");
	}
	printf("front:%d,rear:%d\n",Q->front,Q->rear);
}

/**
 *  @name        : void APrint(void *q)
 *  @description : the funtion uesed to print right data
 *  @param       : q(pointer)
 *  @notice      : None
 */

 void APrint(void *q)
 {
 	if(type == 'i')
		printf("%d",*(int *)q);
	if(type == 'l')
		printf("%ld",*(long *)q);
	if(type == 'f')
		printf("%f",*(float *)q);
	if(type == 'd')
		printf("%lf",*(double *)q);
	if(type == 'c')
		printf("%c",*(char *)q);

	return;
 }

 /**
 *  @name        : InputType
 *	@description : Get the data type
 *	@param		 : none
 *	@return		 : Integer
 *  @notice      : None
 */

 int InputType()
 {
 	int ret = 0;
 	int t = 0;
 	int a = 0;
 	do
	{
		ret = -1;
		t +=1;
		a +=1;
		if(t > 2&&a >= 2)
		{
			ret = -1;
			t = 1;
			printf("\n�������ɵ���������,����������:");
		}
		putchar('\0');
		getchar();
		/*if(t > 1)
		{
			printf("\n����س�\n");
			getchar();
		}*/
		//if(t)type == '\n'||
		//if(t == 1)
		//{
			//printf("\ni->int///l->long///f->float///d->double///c->char\n");

			//printf("ѡ��Ҫ��������ݵ���������:\n");
			//printf("�������ѡ��");
			type = getchar();
			ret = -1;
			t++;
			//continue;
		//}

		if(t==2)
		{
		//if(ret == -1)		//t =
			if(type == 'i')
				return 4;
			else if(type == 'l')
				return 8;
			else if(type == 'f')
				return 4;
			else if(type == 'd')
				return 8;
			else if(type == 'c')
				return 1;
				t==3;
		}
 	}while(ret == -1);
 	t = 0;
 	return 0;
 }

 /**
 *  @name        : InputData(void *data)
 *	@description : Get the data
 *	@param		 : none
 *	@return		 : Integer
 *  @notice      : None
 */
void InputData(void *data) {
	int ret = 0;
	do
	{
		ret = 0;
		//if (getchar() == '\n')
		//{
		if (type == 'i')
			scanf("%d", data, data_size);
		else if (type == 'l')
			scanf("%ld", data, data_size);
		else if (type == 'f')
			scanf("%f", data, data_size);
		else if (type == 'd')
			scanf("%lf", data, data_size);
		else if (type == 'c')
			scanf("%c", data, data_size);

		//	return ;
		//}
		if(getchar() != '\n')
		{
			ret = -1;
			for (; getchar() != '\n';);
			printf("�������������룬����������:", ret);
		}
		else
			return FALSE;
	} while (ret == -1);
}

/**
 *  @name        : int InputNumber()
 *	@description : anti-input-error
 *	@param		 : none
 *	@return		 : int
*/
int Input()
{
	int num = 0;
	int status = 0;
	char str[100];
	do
	{
		scanf("%s", str);
		status = TRUE;
		int i;
		for (i=0;str[i]!='\0';i++)
		{

			if (i == 0)
			{
				if (str[i]=='-'||str[i]=='+'/*||str[i] == '.'*/)
					continue;
			}
			else
			{
				if (str[i] < '0' || str[i] > '9')
				{
					status = FALSE;
				}
			}
		}
		if (status == FALSE)
		{
			printf("����������������:");
		}
		else
		{
			 i = 0;
			for (i = 0, num = 0; str[i] != '\0'; i++)
			{
				if (i == 0)
				{
					if (str[i] == '-' || str[i] == '+')
					{
						continue;
					}
					else
					{
						num *= 10;
						num += (str[i] - 48);
					}
				}
				else
				{
					num *= 10;
					num += (str[i] - 48);
				}
			}
			if (str[0] == '-')
			{

				num = -num;
			}
			// Check if the number entered is out of bounds.
			if (i>=10)
			{
				printf("������Χ������������:");
				status = FALSE;
			}
		}
	} while (status == FALSE);
	return num;
}
