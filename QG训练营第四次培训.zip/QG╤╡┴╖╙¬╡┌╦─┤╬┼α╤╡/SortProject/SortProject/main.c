#include "qgsort.h"

int main()
{
	int flag = 0;
	LinkStack* head = (LinkStack*)malloc(sizeof(StackNode));
	head->top = NULL;
	head->count = 0;
	int a[MAX_SIZE],kk = 0;
	//memset(a,0,MAX_SIZE);
	int n,m,k,*temp = NULL;
	//struct timeval tv,tn;
        time_t tv,tn;
	long ts = 0;
	while(SUCCESS)
	{


LOOG:
                system("cls");
                printf("                               \n");
                printf("          �����㷨��           \n");
                printf("-------------------------------\n");
                printf(">>> 1.��������                 \n");
                printf(">>> 2.�鲢����                 \n");
                printf(">>> 3.��������(�ݹ�)           \n");
                printf(">>> 4.��������(�ǵݹ�)         \n");
                printf(">>> 5.��������                 \n");
                printf(">>> 6.������������             \n");
                printf(">>> 7.��ɫ����                 \n");
                printf(">>> 8.Ѱ�����������е�K������  \n");
                printf(">>> 7.�˳�                     \n");
                printf("-------------------------------\n");
        //printf("��ǰ����״̬:\n");
                if(flag)
                {
                        //printf("-------------------------------\n");
                       // printf("-------------------------------\n");
                        PrintData(a,n);
                        printf("\n");
                        printf("ȷ��ʹ�ø������ݲ��ԣ�\n");
                        printf("��1����  ��2����\n");
                        switch(Input())
                        {
                                case 1:
                                        break;
                                case 2:
                                        flag = 0;
                                        break;
                                default:
                                        printf("�޸����\n");
                                        system("pause");
                                        goto LOOG;
                        }
                                // printf("front:%d,rear:%d\n",head->front,head->rear);
                }
                if(flag == 0)
                {
LOOG1:
                        system("cls");
                        printf("                               \n");
                        printf("          �����㷨��           \n");
                        printf("-------------------------------\n");
                        printf(">>> 1.��������                 \n");
                        printf(">>> 2.�鲢����                 \n");
                        printf(">>> 3.��������(�ݹ�)           \n");
                        printf(">>> 4.��������(�ǵݹ�)         \n");
                        printf(">>> 5.��������                 \n");
                        printf(">>> 6.������������             \n");
                        printf(">>> 7.��ɫ����                 \n");
                        printf(">>> 8.Ѱ�����������е�K������  \n");
                        printf(">>> 9.�˳�                     \n");
                        printf("-------------------------------\n");
                        printf("��û�����ݣ�\n");
                        printf("-------------------------------\n");
                        printf("������Ŵ���һ�����ݻ��˳�����:\n");
                        printf("1.�ֶ�����һ������\n");
                        printf("2.�趨���ݸ���,ϵͳ���һ������,��������д���ļ�\n");
                        printf("3.��ȡ���ݲ�����\n");
                        printf("4.����С��������\n");
                        printf("0.�˳�����\n");
                        switch(Input())
                        {
                                case 0:
                                        exit(0);
                                case 1:
                                        n = InputData(a);
                                        break;
                                case 2:
                                        test(a,&n);
                                        break;
                                case 3:
                                        read(a,&n);
                                        if(a[1] == 0)
                                        {
                                                printf("�ļ�Ϊ��\n");
                                                system("pause");
                                                goto LOOG;
                                        }
                                        break;
                                case 4:
                                        printf("�Ƿ���д���С��������?:");
                                        printf("��1����  ��2����\n");
                                        switch(Input())
                                        {
                                                case 1:
                                                        test11(a,&n);
                                                        kk = 1000000;
                                                        break;
                                                case 2:
                                                        goto LOOG;
                                        }
                                        break;
                                default:
                                        printf("û�����ѡ��!");
                                        system("pause");
                                        goto LOOG;
                        }
                        flag = 1;
                        continue;
                }
                printf("--------------------------\n");
                printf("������ſ����ж�Ӧ�㷨:");
                        switch(Input())
                        {

                                case 1:
                                        while(kk--)
                                        {//LOOG:
                                                tv = time(NULL);
                                                insertSort(a,n);
                                                tn = time(NULL);
                                                ts += (tn - tv)*1000;
                                        }
                                        //flag = 1;
                                        break;
                                case 2:
                                        while(kk--)
                                        {
                                                tv = time(NULL);
                                                MergeSort(a,0,n-1,temp);
                                                tn = time(NULL);
                                                ts += (tn - tv)*1000;
                                        }
                                                break;
                                case 3:
                                        while(kk--)
                                        {
                                                tv = time(NULL);
                                                QuickSort_Recursion(a,0,n-1);
                                                tn = time(NULL);
                                                ts += (tn - tv)*1000;
                                        }
                                        break;
                                case 4:
                                        tv = time(NULL);
                                        QuickSort(a,n);
                                        tn = time(NULL);
                                        ts += (tn - tv)*1000;
                                        //printf("QS");
                                        break;
                                case 5:
                                        tv = time(NULL);
                                        m = a[0];
                                        for(int i = 0;i < n; i++)
                                        {
                                                if(a[i] >= m )
                                                        m = a[i];
                                        }
                                        printf("%d\n",m);
                                        CountSort(a,n,m);
                                        tn = time(NULL);
                                        ts += (tn - tv)*1000;
                                        break;
                                case 6:
                                        tv = time(NULL);
                                        RadixCountSort(a,n);
                                        tn = time(NULL);
                                       ts += (tn - tv)*1000;

                                        break;
                                case 7:
                                        tv = time(NULL);
                                        m = CheckColorData(a,n);
                                        if(m == -1)
                                        {
                                                printf("���ݲ�����\n");
                                                goto LOOG1;
                                        }
                                        ColorSort(a,n);
                                        tn = time(NULL);
                                        ts += (tn - tv)*1000;
                                        break;
                                case 8:
                                        printf("Ҫ���ҵڼ���������أ�\n");
                                        while(1)
                                        {
                                                        k = Input();
                                                if(k <= n )
                                                {       tv = time(NULL);
                                                        m = No_K(a,n,k);
                                                        tn = time(NULL);
                                                        printf("�� %d ������Ϊ %d\n",k,m);
                                                       ts += (tn - tv)*1000;
                                                        break;
                                                }
                                                printf("������Χ�����������롣");
                                        }
                                        break;
                                case 9:
                                        exit(0);
                                default:
                                        printf("�޸����\n");
                                        break;
                        }
        printf("������ʱ: %ld ms\n",ts);
        system("pause");
        }
    return 0;
}
