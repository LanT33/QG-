
#include<stdbool.h>
#include "binary_sort_tree.h"
bool isInited = false; // ��ʼ����־


// ��ʼ��������
Status  BST_init(BinarySortTreePtr T)
{
    int n = InputNumber();
    T->root = (NodePtr)malloc(sizeof(Node));
    T->root->value = n;
    T->root->left= NULL;
    T->root->right = NULL;
    isInited = true;
    printf("\n�ɹ�����������\n");
    return succeed;
}

Status BST_insert(BinarySortTreePtr T, ElemType n)
{
    if (T->root == NULL)
    {
        printf("δ��ʼ�������ѿ�\n");
        return failed;
    }
    if(n < T->root->value)
    {
        if(T->root->left == NULL)
        {
            printf("δ\n");
            printf("q = %s\n",T->root->left);
            T->root->left = (NodePtr)malloc(sizeof(Node));
            T->root = T->root->left;
            T->root->value = n;
            T->root->left= NULL;
            T->root->right = NULL;
            printf("q = %d\n",T->root->value);
            system("pause");
            return succeed;
        }
       T->root = T->root->left;
       BST_insert(T,n);
    }
    else if(n > T->root->value)
    {
        if(T->root->right == NULL)
        {
            printf("δ��\n");
            printf("q = %s\n",T->root->right);
            T->root->right = (NodePtr)malloc(sizeof(Node));
            T->root = T->root->right;
            T->root->value = n;
            T->root->left= NULL;
            T->root->right = NULL;
            printf("q = %d\n",T->root->value);
            system("pause");
            return succeed;
        }
        T->root = T->root->right;
        BST_insert(T,n);
    }

    else if(n == T->root->value)
    {
        printf("������������ %d ��\n",n);
        system("pause");
        return failed;
    }

}



NodePtr BST_Fsearch(NodePtr parent, ElemType value)
{
    NodePtr result = NULL;
    if(parent != NULL)
    {
        if(value < parent->value && parent->left != NULL)
        {
            if(value == parent->left->value)
            {
                result = parent;
                //flag = 1;
            }
            else
            {
                result = BST_Fsearch(parent->left,value);
                if(result == NULL)
                    result = BST_Fsearch(parent->right,value);
            }
        }
        if(value > parent->value && parent->right != NULL)
        {
            if(value == parent->right->value)
            {
                result = parent;
                //flag = 2;
            }
            else
            {
                result = BST_Fsearch(parent->left,value);
                if(result == NULL)
                    result = BST_Fsearch(parent->right,value);
            }
        }
        if(value == parent->value)
            return parent;
    }
    return result;
}

Status BST_delete(BinarySortTreePtr p, ElemType n)
{

    NodePtr q,s,m,k;
    m = (NodePtr)malloc(sizeof(Node));
    q = (NodePtr)malloc(sizeof(Node));
    k = (NodePtr)malloc(sizeof(Node));
    int flag =0;
    m = p->root;
    q = p->root;
    //printf("q = %d\n",q->value);
    p->root = BST_Fsearch(q,n);
   // printf("p = %d\n",p->root->value);
    if(p->root == NULL)
        return failed;
    else if(p->root->left != NULL&&p->root->left->value == n)
        k = p->root->left;
    else if(p->root->right != NULL&&p->root->right->value == n)
        k = p->root->right;
    else if(p->root->value == n)
        k = p->root;
    else
        return failed;
    if(k->left == NULL && k->right == NULL )
    {
        //printf("1\n");
        if(k == p->root->left)
        {
            p->root->left =NULL;
        }
        else if(k == p->root->right)
        {
            p->root->right = NULL;
        }
        else if(k == m)
        {
            p->root == NULL;
            //   printf("q:%s",q);
            return 4;
        }
        //q = p->root->left;
        free(k);
        k = NULL;

        //printf("�������� %d ��\n");
    }
    else if(k->left != NULL && k->right == NULL)
    {
        //printf("2\n");
       // system("pause");
        q = k->left;
        k->value = q->value;
        k->right = q->right;
        k->left = q->left;
        free(q);
        q = NULL;

    }
    else if(k->left  == NULL && k->right != NULL)
    {
       // printf("3\n");
       // system("pause");
        q = k->right;
        k->value= q->value;
        k->right = q->right;
        k->left = q->left;
        free(q);
        q = NULL;
    }
    else if(k->left != NULL && k->right != NULL)
    {
        //printf("4\n");
       // system("pause");
        q = k;
        s = k->left;
        while(s->right)
        {
            q = s;
            s = s->right;
            //printf("q = %d\n",q->value);
        }
        k->value = s->value;
        if(q != k)
        q->right = s->left;
        else
            q->left = q->left->left;
       // printf("q = %s\n",q);
        free(s);
        s = NULL;
        //printf("k = %d\n",k->value);
        //printf("s = %s\n",s);
    }
    return succeed;
}

Status BST_search(BinarySortTreePtr T, ElemType n)////��
{

    if(T->root == NULL)
    {

        printf("δ��ʼ��������û�и����ݡ�\n");
        return failed;
    }
    else if(n == T->root->value)
    {

        printf("���С�\n");
        //printf("���������� %d ��\n",n);
        return succeed;
    }
    else if(n < T->root->value)
    {
        printf("root = %d\n",T->root->value);
        printf("left = %s\n",T->root->left);
        system("pause");

       T->root = T->root->left;
       BST_search(T,n);
    }
    else if(n > T->root->value)
    {
        printf("root = %d\n",T->root->value);
        printf("left = %s\n",T->root->left);
        system("pause");

       T->root = T->root->right;
       BST_search(T,n);
    }
}


Status BST_preorderI(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    if (T->root == NULL)
    {
        printf("δ��ʼ��\n");
        return failed;
    }
    LQueue Q;
    NodePtr t = (NodePtr)malloc(sizeof(Node));
    Q.front = Q.rear = NULL;
    Q.length = 0;
    InitLQueue(&Q);
    EnLQueue(&Q, T->root); // ���ڵ����

    while (!IsEmptyLQueue(&Q))
    {
        GetHeadLQueue(&Q,t);
        DeLQueue(&Q);
        visit(t); // ���ʽ��
        if (t->right != NULL)
            EnLQueue(&Q, t->right); // ���
        if (t->left != NULL)
            EnLQueue(&Q, t->left); // ���
    }
}
// �������
Status BST_preorderR(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    if (T->root == NULL)
    {
        printf("δ��ʼ��\n");
        return failed;
    }
    visit(T->root);
    if (T->root->left != NULL)
    {
        //printf("δʼ��\n");
        preorderR(T->root->left, visit);
    }
    if (T->root->right != NULL)
    {
        //printf("δ��ʼ\n");
        preorderR(T->root->right, visit);
    }

}


Status preorderR(NodePtr T, void (*visit)(NodePtr))
{
    visit(T);
    if(T->left != NULL)
    {
        //printf("δʼ��\n");
        preorderR(T->left, visit);
    }
    if (T->right != NULL)
    {
        //printf("δ��ʼ\n");
        preorderR(T->right, visit);
    }
}

Status BST_inorderI(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    if (T->root == NULL)
    {
        printf("δ��ʼ��\n");
        return failed;
    }
    int a = 0;
    LQueue Q;
    NodePtr t;
    NodePtr stack[30];
    NodePtr s;
    t = (NodePtr)malloc(sizeof(Node));
    //s = (NodePtr)malloc(sizeof(Node));
   // t->left = t->right = NULL;
    //s->left = s->right = NULL;
    Q.front = Q.rear = NULL;
    Q.length = 0;
    //InitLQueue(&Q);
   // EnLQueue(&Q,T->root);
    //t = T->root; // ���ڵ����
    t->left =  T->root->left;
    t->right = T->root->right;
    t->value = T->root->value;
    while(a != 0||t)
    {
            //printf("δ��\n");
        while(t)
        {
            stack[a++] = t;
            t = t->left;
        }
        t = stack[--a];
        printf("%d ",t->value);
        t = t->right;

    }

}

// �������
Status BST_inorderR(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    if (T->root == NULL)
    {
        printf("δ��ʼ��\n");
        return failed;
    }
    //printf("��ʼ��\n");
    if (T->root->left != NULL)
    {
        //m->root = ;
        inorderR(T->root->left, visit);
    }
    visit(T->root);
    if (T->root->right != NULL)
    {
        //n->root = ;
        inorderR(T->root->right, visit);
    }
}

Status inorderR(NodePtr T, void (*visit)(NodePtr))
{
    if(T->left != NULL)
    {
        //printf("δʼ��\n");
        inorderR(T->left, visit);
    }
    visit(T);
    if (T->right != NULL)
    {
        //printf("δ��ʼ\n");
        inorderR(T->right, visit);
    }
}


Status BST_postorderI(BinarySortTreePtr T, void (*visit)(NodePtr))
{
        if (T->root == NULL)
    {
        printf("δ��ʼ��\n");
        return failed;
    }
  //  int a = 0;
    //LQueue Q;
    NodePtr t;
    NodePtr stack[30];
//    NodePtr s;
    t = (NodePtr)malloc(sizeof(Node));
    t->left =  T->root->left;
    t->right = T->root->right;
    t->value = T->root->value;
    int top = -1;
    int flagStack[30];   //��¼ÿ���ڵ���ʴ���ջ
    while(t!=NULL||top!=-1)
    {
        if(t!=NULL)
        {     //��һ�η��ʣ�flag��1����ջ
            stack[++top] = t;
            flagStack[top] = 1;
            t = t->left;
        }
        else
        {//��p == NULL��
            if(flagStack[top] == 1)
            {  //�ڶ��η��ʣ�flag��2��ȡջ��Ԫ�ص�����ջ
                t = stack[top];
                flagStack[top] = 2;
                t = t->right;
            }else
            {         //�����η��ʣ���ջ
                t = stack[top --];
                visit(t);    //��ջʱ���������
                t = NULL;      //p�ÿգ��Ա������ջ
            }
        }
    }
}
// �������
Status BST_postorderR(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    if (T->root == NULL)
    {
        printf("δ��ʼ��\n");
        return failed;
    }

    if (T->root->left != NULL)
    {
        //printf("δʼ��\n");
        //m->root = T->root->left;
        postorderR(T->root->left, visit);
    }
    if (T->root->right != NULL)
    {
        //printf("δ��ʼ\n");
        //n->root = T->root->right;
        postorderR(T->root->right, visit);
    }
    visit(T->root);

}

Status postorderR(NodePtr T, void (*visit)(NodePtr))
{
    if (T->left != NULL)
    {
        //printf("δʼ��\n");
        postorderR(T->left,visit);
    }
    if (T->right != NULL)
    {
        //printf("δ��ʼ\n");
        postorderR(T->right,visit);
    }
    visit(T);
}
// �������
Status BST_levelOrder(BinarySortTreePtr T, void (*visit)(NodePtr))
{
    if (T->root == NULL)
    {
        printf("δ��ʼ��\n");
        return failed;
    }
    LQueue Q;
    NodePtr t = (NodePtr)malloc(sizeof(Node));////���ӿռ������������
    Q.front = Q.rear = NULL;
    Q.length = 0;
    InitLQueue(&Q);
    EnLQueue(&Q, T->root); // ���ڵ����

    while (!IsEmptyLQueue(&Q))
    {
        GetHeadLQueue(&Q,t);
        //printf("t:%d",t->value);
        DeLQueue(&Q);
        //printf("t:%d",t->value);
        visit(t); // ���ʽ��
        if(t->left != NULL)
            EnLQueue(&Q,t->left); // ���
        if (t->right != NULL)
            EnLQueue(&Q,t->right); // ���
    }
}

void Print(NodePtr p)
{
    printf("%d ", p->value);
}


/**
 *  @name        : InputNumber
 *	@description : to input a checked number
 *	@param		 : none
 *	@return		 : int
 *  @notice      : None
 */
int InputNumber()
{
    int n = 0;
    int num = 0; // �����������
    int status = 0; // ��־״̬
     //printf("��������(����):");
    do
    {
        status = TRUE;
        n = scanf("%d", &num);//
        if (getchar() != '\n')
        {
            for (; getchar() != '\n';);
            printf("�Ƿ�����,���ٴγ���:");
            status = FALSE;
        }
    } while (status == FALSE);
    return num;
}

